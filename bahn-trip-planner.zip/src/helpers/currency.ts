export const getCurrencySymbol = (code: string) => {
  switch (code) {
    case "EUR":
      return "€";
    default:
      return "€";
  }
};
