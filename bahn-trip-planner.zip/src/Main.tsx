import React from "react";

import SearchJourneyForm from "./components/forms/SearchJourneyForm";
import JourneyList from "./components/JourneyList";

const Main = () => {
  return (
    <div>
      <div className="flex justify-center pt-8 pb-4 text-4xl">Trip Planner</div>
      <div className="flex flex-col space-y-4 space-x-0 items-center md:flex-row justify-around md:items-start md:space-y-0 p-6">
        <SearchJourneyForm />
        <JourneyList />
      </div>
    </div>
  );
};

export default Main;
